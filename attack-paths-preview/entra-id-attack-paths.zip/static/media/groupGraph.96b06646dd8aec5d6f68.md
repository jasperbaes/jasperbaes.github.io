## Graph API permissions

This is a logical grouping node for all Graph API permission nodes in the visualization. It visually groups all nodes representing specific Graph API permissions.
