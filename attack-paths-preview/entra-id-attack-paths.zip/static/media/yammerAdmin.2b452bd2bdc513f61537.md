## Yammer Administrator

Can access and manage Yammer communications, potentially exposing sensitive discussions.