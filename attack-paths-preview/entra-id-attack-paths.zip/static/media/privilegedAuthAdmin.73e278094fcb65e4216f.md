## Privileged Authentication Administrator

Can reset credentials for privileged accounts, enabling privilege escalation.