## Policy.ReadWrite.ConditionalAccess

Grants the ability to manage Conditional Access policies via Microsoft Graph API. This permission can be used to create or modify policies that allow or block access, potentially leading to tenant lockout or privilege escalation.
