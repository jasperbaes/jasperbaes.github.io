## SharePoint Administrator

Can access and manage all SharePoint sites, potentially exposing sensitive data.