## Partner Tier2 Support

Provides advanced support with elevated privileges.

> This role has been deprecated and will be removed from Microsoft Entra ID in the future. Don't use this role.