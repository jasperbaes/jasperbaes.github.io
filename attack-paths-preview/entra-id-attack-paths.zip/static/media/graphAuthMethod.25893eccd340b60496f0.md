## UserAuthenticationMethod.ReadWrite.All

Allows management of user authentication methods via Microsoft Graph API. This permission can be used to reset or change authentication methods, potentially bypassing MFA or other controls.
