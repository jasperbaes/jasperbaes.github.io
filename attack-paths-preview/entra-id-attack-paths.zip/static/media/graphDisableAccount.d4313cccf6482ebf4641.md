## User.EnableDisableAccount.All

Allows enabling or disabling user accounts via Microsoft Graph API.  
This permission can be used to disrupt access or enable accounts for privilege escalation.
