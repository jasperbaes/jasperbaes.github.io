## Hybrid Identity Administrator

Can modify synchronization settings and introduce malicious accounts or administrators.