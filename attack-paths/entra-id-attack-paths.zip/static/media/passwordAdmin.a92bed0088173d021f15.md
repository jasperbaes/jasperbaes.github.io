## Password Administrator

Can reset passwords for users and administrators. They cannot reset passwords for Global Administrators.