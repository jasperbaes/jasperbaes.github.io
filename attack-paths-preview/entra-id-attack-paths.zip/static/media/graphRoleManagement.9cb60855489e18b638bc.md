## Node: RoleManagement.ReadWrite.Directory

Grants management of directory role management via Microsoft Graph API. This permission can be used to assign or remove directory roles, including privileged roles.
