## Has Graph API Permissions

Indicates that the user or identity has been granted one or more Microsoft Graph API permissions.  
