## Application Administrator

Can manage all applications in the directory.

**Note:** Application Administrators are not added as owners when creating a new App Registration or Enterprise Application.