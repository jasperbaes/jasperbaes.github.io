## Windows 365 Administrator

Can provision and manage Cloud PCs, potentially exposing sensitive environments.