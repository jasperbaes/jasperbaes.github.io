## Lifecycle Workflows Administrator

Can automate onboarding/offboarding/moving Lifecycle Workflows that may result in privilege escalation or data exposure.