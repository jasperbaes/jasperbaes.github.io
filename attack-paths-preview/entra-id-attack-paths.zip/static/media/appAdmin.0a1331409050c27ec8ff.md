## Application Administrator

Can manage all applications in the directory.