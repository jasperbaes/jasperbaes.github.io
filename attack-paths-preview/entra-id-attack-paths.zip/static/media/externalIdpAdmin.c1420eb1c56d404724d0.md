## External Identity Provider Administrator

Can configure external IdPs, potentially enabling unauthorized access.