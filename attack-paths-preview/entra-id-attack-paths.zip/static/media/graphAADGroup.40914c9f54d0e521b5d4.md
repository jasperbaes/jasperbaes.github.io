## PrivilegedAccess.ReadWrite.AzureADGroup

Grants management of privileged access to Azure AD groups via Microsoft Graph API. This permission can be used to escalate privileges by modifying group memberships.
