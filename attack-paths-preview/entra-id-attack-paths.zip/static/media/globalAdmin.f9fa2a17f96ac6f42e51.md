## Global Administrator

The highest privileged role in the tenant.

**Attack Path:** Full control over all Entra and Azure resources; compromise can lead to total tenant takeover.