## RoleAssignmentSchedule.ReadWrite.Directory

Allows management of role assignment schedules in the directory via Microsoft Graph API. This permission can be used to assign privileged roles to users or identities.
