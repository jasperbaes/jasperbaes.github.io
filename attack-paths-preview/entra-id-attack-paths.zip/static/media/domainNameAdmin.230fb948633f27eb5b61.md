## Domain Name Administrator

Can add or remove domains, potentially enabling domain hijacking.
