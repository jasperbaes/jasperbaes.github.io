## Groups Administrator

Can add and remove groups and group membership; potentially adding users to privileged groups.