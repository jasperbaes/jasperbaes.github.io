## User Administrator

Can manage users and groups (except Global Administrators).