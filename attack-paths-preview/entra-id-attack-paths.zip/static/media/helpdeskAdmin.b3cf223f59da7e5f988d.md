## Helpdesk Administrator

Can reset passwords, potentially allowing attackers to take over accounts.