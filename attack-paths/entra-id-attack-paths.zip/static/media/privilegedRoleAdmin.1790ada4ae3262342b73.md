## Privileged Role Administrator

Can assign themselves or others to privileged roles, including Global Admin.