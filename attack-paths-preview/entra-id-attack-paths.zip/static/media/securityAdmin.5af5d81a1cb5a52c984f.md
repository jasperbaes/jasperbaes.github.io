## Security Administrator

Can add, modify and delete  security settings and policies, including Conditional Access policies.