## Knowledge Administrator

Can access and manage knowledge bases (Viva Topics and knowledge resources), potentially exposing sensitive information.