## PrivilegedAssignmentSchedule.ReadWrite.AzureADGroup

Allows management of privileged assignment schedules for Azure AD groups via Microsoft Graph API. This can be used to schedule or assign privileged roles to users or identities.
