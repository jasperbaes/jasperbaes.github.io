## Intune Administrator

Manages Intune device and app policies.