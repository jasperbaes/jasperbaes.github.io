## Exchange Administrator

Has permissions to manage Exchange Online, including accessing mailboxes, configuring settings, and modifying policies such as mail flow rules.

**Note:** To manage group memberships, the Exchange Administrator must be the owner of the group.