## Exchange Administrator

Can access mailboxes, configure Exchange Online and modify policies like Mail Flow Rules.