## Cloud Application Administrator

Can manage cloud applications, Service principals and App Registrations; potentially grant excessive permissions.