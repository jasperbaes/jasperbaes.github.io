## User Account

Represents a standard user account or privileged user account in the environment with owner permissions on a privileged Service Principal.