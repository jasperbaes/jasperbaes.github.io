## Azure DevOps Administrator

This role can manage Azure DevOps resources and pipelines.