## Directory Writers

Can add, modify and deelte directory objects (users and groups).