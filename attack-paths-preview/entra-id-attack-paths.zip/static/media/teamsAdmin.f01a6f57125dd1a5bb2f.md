## Teams Administrator

Can manage Teams settings and permissions, potentially exposing communication channels.