## Identity Governance Administrator

Can add, modify and delete Identity Governance features.