## User.DeleteRestore.All

Allows deletion or restoration of users via Microsoft Graph API.  
This permission can be abused to remove or restore user accounts, including privileged accounts.
