## Partner Tier1 Support

Provides support with limited admin privileges.

> This role has been deprecated and will be removed from Microsoft Entra ID in the future. Don't use this role.