## Add a new secret to existing an App Registration

Represents the ability to directly assign a new application secret.

**Attack Path:** Allows attackers to take over all App Registrations.