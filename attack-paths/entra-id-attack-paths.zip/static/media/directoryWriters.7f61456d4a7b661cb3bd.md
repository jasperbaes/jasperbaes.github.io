## Directory Writers

Can add, modify and delete directory objects (users and groups).