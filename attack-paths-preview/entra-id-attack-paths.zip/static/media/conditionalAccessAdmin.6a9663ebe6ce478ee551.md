## Conditional Access Administrator

Can add, modify and delete Conditional Access policies.