## Knowledge Manager

Can update or remove knowledge content, potentially hiding evidence or exposing data.