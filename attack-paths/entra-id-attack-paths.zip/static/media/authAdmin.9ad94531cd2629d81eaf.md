## Authentication Administrator

Can manage authentication methods for users and reset credentials for (privileged) accounts.
